package com.example.videoenhancer

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** Автокоррекция: анализирует несколько кадров и подбирает параметры. */
object AutoCorrect {

    fun analyze(context: Context, uri: Uri): EnhanceParams {
        val out = EnhanceParams()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, uri)
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val hist = IntArray(256)
            var n = 0L
            var sr = 0.0; var sg = 0.0; var sb = 0.0; var sSat = 0.0; var sLum = 0.0
            for (frac in listOf(0.2, 0.5, 0.8)) {
                val bmp: Bitmap = r.getScaledFrameAtTime(
                    (durMs * 1000 * frac).toLong(),
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 160, 160
                ) ?: continue
                val px = IntArray(bmp.width * bmp.height)
                bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
                for (p in px) {
                    val rr = ((p shr 16) and 0xFF) / 255.0
                    val gg = ((p shr 8) and 0xFF) / 255.0
                    val bb = (p and 0xFF) / 255.0
                    val lum = 0.2126 * rr + 0.7152 * gg + 0.0722 * bb
                    hist[(lum * 255).toInt().coerceIn(0, 255)]++
                    sr += rr; sg += gg; sb += bb; sLum += lum
                    sSat += max(rr, max(gg, bb)) - min(rr, min(gg, bb))
                    n++
                }
                bmp.recycle()
            }
            if (n == 0L) return defaults(out)

            val mr = sr / n; val mg = sg / n; val mb = sb / n
            val mLum = sLum / n
            val mSat = sSat / n

            fun percentile(q: Double): Double {
                val target = (n * q).toLong()
                var acc = 0L
                for (i in 0..255) { acc += hist[i]; if (acc >= target) return i / 255.0 }
                return 1.0
            }
            val p2 = percentile(0.02)
            val p98 = percentile(0.98)
            val range = p98 - p2

            val v = out.v
            v[P.EXPOSURE] = (ln(0.42 / max(mLum, 0.02)) / ln(2.0) / 1.5 * 0.7)
                .coerceIn(-0.5, 0.5).toFloat()
            v[P.CONTRAST] = ((0.85 - range) * 0.8).coerceIn(-0.1, 0.4).toFloat()
            v[P.TEMPERATURE] = ((mb - mr) * 2.0).coerceIn(-0.4, 0.4).toFloat()
            v[P.TINT] = ((mg - (mr + mb) / 2.0) * 2.0).coerceIn(-0.3, 0.3).toFloat()
            v[P.SATURATION] = (if (mSat < 0.25) 0.25 else 0.08).toFloat()
            v[P.VIBRANCE] = 0.2f
            v[P.SHARPEN] = 0.35f
            v[P.STRUCTURE] = 0.3f
            v[P.CLARITY] = 0.15f
            if (abs(v[P.EXPOSURE]) < 0.03f) v[P.EXPOSURE] = 0f
            return out
        } catch (e: Exception) {
            return defaults(out)
        } finally {
            r.release()
        }
    }

    private fun defaults(p: EnhanceParams): EnhanceParams {
        p.v[P.SHARPEN] = 0.35f; p.v[P.STRUCTURE] = 0.3f; p.v[P.CLARITY] = 0.15f
        p.v[P.CONTRAST] = 0.1f; p.v[P.SATURATION] = 0.1f
        return p
    }
}
