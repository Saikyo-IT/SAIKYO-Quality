Video Enhancer (Android, Kotlin, Media3)

Сборка APK:
1. Установите Android Studio (последняя версия), распакуйте архив.
2. File > Open > папка VideoEnhancer, дождитесь Gradle Sync (нужен интернет).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   APK: app/build/outputs/apk/debug/app-debug.apk
4. Перенесите APK на телефон и установите (разрешите установку из неизвестных источников).

Либо подключите телефон по USB (отладка по USB) и нажмите Run.
